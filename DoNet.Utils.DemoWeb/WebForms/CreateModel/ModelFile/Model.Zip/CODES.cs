﻿ using DotNet.Utils;
 using System;
 namespace Models
{
  /// <summary>
/// CODES
/// </summary>
  public  class CODES
{
  /// <summary>
/// 
/// </summary>
[Column(Identity =true)]
  public   string TYPENAME { get; set; }

  /// <summary>
/// 
/// </summary>
  public   string CODENAME { get; set; }

  /// <summary>
/// 
/// </summary>
  public   string CODEVALUE { get; set; }

  /// <summary>
/// 
/// </summary>
  public   int? CODEORDER { get; set; }

  /// <summary>
/// 
/// </summary>
  public   string GRADE { get; set; }

  /// <summary>
/// 
/// </summary>
  public   string SUPERCODE { get; set; }

  /// <summary>
/// 
/// </summary>
  public   string FLAG { get; set; }

  /// <summary>
/// 备注
/// </summary>
  public   string REMARK { get; set; }

  /// <summary>
/// 主键
/// </summary>
  public   int? ID { get; set; }

 }
public class CODESManage : CRUDHelper<CODES>
{ 
}
 }

