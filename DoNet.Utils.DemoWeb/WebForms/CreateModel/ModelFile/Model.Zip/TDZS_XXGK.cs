﻿ using DotNet.Utils;
 using System;
 namespace Models
{
  /// <summary>
/// 用户表
/// </summary>
  public  class TDZS_XXGK
{
  /// <summary>
/// 标识列
/// </summary>
[Column(Identity =true)]
  public   string ID { get; set; }

  /// <summary>
/// 名称
/// </summary>
  public   string NAME { get; set; }

  /// <summary>
/// 批准文号
/// </summary>
  public   string WH { get; set; }

  /// <summary>
/// 批准日期
/// </summary>
  public   DateTime? RQ { get; set; }

  /// <summary>
/// 批准机关
/// </summary>
  public   string PZJG { get; set; }

  /// <summary>
/// 所属地市
/// </summary>
  public   string SSDS { get; set; }

  /// <summary>
/// 所属区县
/// </summary>
  public   string SSQX { get; set; }

  /// <summary>
/// 所属乡镇街道
/// </summary>
  public   string SSXZJD { get; set; }

  /// <summary>
/// 所属村居(单位)
/// </summary>
  public   string SSCJ { get; set; }

  /// <summary>
/// 状态:1.发布;2.未发布;3.撤回
/// </summary>
  public   int? STATE { get; set; }

  /// <summary>
/// 发布人
/// </summary>
  public   string FBR { get; set; }

  /// <summary>
/// 发布时间
/// </summary>
  public   DateTime? FBSJ { get; set; }

 }
public class TDZS_XXGKManage : CRUDHelper<TDZS_XXGK>
{ 
}
 }

