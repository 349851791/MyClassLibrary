﻿ using DotNet.Utils;
 using System;
 namespace Models
{
  /// <summary>
/// ZBGL_PHJG47
/// </summary>
  public  class ZBGL_PHJG47
{
  /// <summary>
/// 项目(批次)名称
/// </summary>
[Column(Identity =true)]
  public   string PRJNAME { get; set; }

  /// <summary>
/// 年度
/// </summary>
  public   string PRJYEAR { get; set; }

  /// <summary>
/// 农用地转用及土地征收批准文号
/// </summary>
  public   string APRDOCNO { get; set; }

  /// <summary>
/// 批复时间
/// </summary>
  public   DateTime? PFDATE { get; set; }

  /// <summary>
/// 批复用途
/// </summary>
  public   string PFYT { get; set; }

  /// <summary>
/// 批准总用地面积
/// </summary>
  public   int? PZZYDMJ { get; set; }

  /// <summary>
/// 新增建设用地面积
/// </summary>
  public   int? XZJSYDMJ { get; set; }

  /// <summary>
/// 农用地面积
/// </summary>
  public   int? NYDMJ { get; set; }

  /// <summary>
/// 耕地面积
/// </summary>
  public   int? GDMJ { get; set; }

  /// <summary>
/// 完成时间
/// </summary>
  public   DateTime? WCSJ { get; set; }

  /// <summary>
/// 未完成面积
/// </summary>
  public   int? WWCMJ { get; set; }

  /// <summary>
/// “两公告一登记”(√)
/// </summary>
  public   string LGGYDJ { get; set; }

  /// <summary>
/// 供地面积
/// </summary>
  public   int? GONGDMJ { get; set; }

  /// <summary>
/// 未供地面积
/// </summary>
  public   int? WGDMJ { get; set; }

  /// <summary>
/// 用地单位名称
/// </summary>
  public   string YDDWMJ { get; set; }

  /// <summary>
/// 供地批准文号
/// </summary>
  public   string GDPZWH { get; set; }

  /// <summary>
/// 供地时间
/// </summary>
  public   DateTime? GDSJ { get; set; }

  /// <summary>
/// 供地方式
/// </summary>
  public   string GDFS { get; set; }

  /// <summary>
/// 供地用途
/// </summary>
  public   string GDYT { get; set; }

  /// <summary>
/// 宗地供地面积
/// </summary>
  public   int? ZDGDMJ { get; set; }

  /// <summary>
/// 实测
/// </summary>
  public   int? SC { get; set; }

  /// <summary>
/// 踏查
/// </summary>
  public   int? TC { get; set; }

  /// <summary>
/// 应缴出让金
/// </summary>
  public   int? YJCRJ { get; set; }

  /// <summary>
/// 实缴出让金
/// </summary>
  public   int? SJCRJ { get; set; }

  /// <summary>
/// 合同开工时间
/// </summary>
  public   DateTime? HTKGSJ { get; set; }

  /// <summary>
/// 合同竣工时间
/// </summary>
  public   DateTime? HTJGSJ { get; set; }

  /// <summary>
/// 实际开工时间
/// </summary>
  public   DateTime? SJKGSJ { get; set; }

  /// <summary>
/// 实际竣工时间
/// </summary>
  public   DateTime? SJJGSJ { get; set; }

  /// <summary>
/// 容积率
/// </summary>
  public   string RJL { get; set; }

  /// <summary>
/// 建筑密度(%)
/// </summary>
  public   string JZMD { get; set; }

  /// <summary>
/// 绿地率(%)
/// </summary>
  public   string LDL { get; set; }

  /// <summary>
/// 行政办公比例
/// </summary>
  public   string XZBGBL { get; set; }

  /// <summary>
/// 投资强度
/// </summary>
  public   string TZQD { get; set; }

  /// <summary>
/// 已竣工(√)
/// </summary>
  public   string YJG { get; set; }

  /// <summary>
/// 正在建设(√)
/// </summary>
  public   string ZZJS { get; set; }

  /// <summary>
/// 未开工(√)
/// </summary>
  public   string WKG { get; set; }

  /// <summary>
/// 停建(√)
/// </summary>
  public   string TJ { get; set; }

  /// <summary>
/// 用而未尽面积
/// </summary>
  public   int? WEWJMJ { get; set; }

  /// <summary>
/// 是否改变用途(√)
/// </summary>
  public   string SFGBYT { get; set; }

  /// <summary>
/// 少批多占面积
/// </summary>
  public   int? SPDZMJ { get; set; }

  /// <summary>
/// 超占面积
/// </summary>
  public   int? CZMJ { get; set; }

  /// <summary>
/// 移位面积
/// </summary>
  public   int? YWMJ { get; set; }

  /// <summary>
/// 未供先建
/// </summary>
  public   int? WGXJ { get; set; }

  /// <summary>
/// 闲置费
/// </summary>
  public   int? XZF { get; set; }

  /// <summary>
/// 是否收回(√)
/// </summary>
  public   string SFHS { get; set; }

  /// <summary>
/// 处罚时间
/// </summary>
  public   DateTime? CFSJ { get; set; }

  /// <summary>
/// 处罚面积
/// </summary>
  public   int? CFMJ { get; set; }

  /// <summary>
/// 主键
/// </summary>
  public   int? ZBGL_PHJG47_ID { get; set; }

  /// <summary>
/// 行政区市
/// </summary>
  public   string XZQ { get; set; }

  /// <summary>
/// 导入时间
/// </summary>
  public   DateTime? INDATE { get; set; }

  /// <summary>
/// 行政区县
/// </summary>
  public   string XZQX { get; set; }

  /// <summary>
/// 附件路径
/// </summary>
  public   string FILEPATH { get; set; }

  /// <summary>
/// 是否为最新导入状态（0最新,1历史）
/// </summary>
  public   int? ISNEW { get; set; }

  /// <summary>
/// 是否上传报告书(0未上传，1已上传)
/// </summary>
  public   string ISUPLOAD { get; set; }

 }
public class ZBGL_PHJG47Manage : CRUDHelper<ZBGL_PHJG47>
{ 
}
 }

